<?php

namespace App\Http\Controllers\Front\ajax;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\consulta_option;

class Ajax extends Controller
{
    public function consulta_option($option)
    {
        $data = consulta_option::where("id", "=", $option)->get();
        return view("Admin.consulta.ajax_option", compact("data"));
    }
}
