<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Message;
use Illuminate\Support\Facades\Auth;
use App\Events\MessageSent;
use App\Models\User;

class Orders extends Controller
{
    public function index()
    {
        return view('admin.orders.index');
    }
    public function chat()
    {
        $users = User::where('id', '!=', 1)->get();
        return view('home', compact('users'));
    }
}
