<?php

namespace App\Http\Controllers\chat;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ChatRoom;
use Illuminate\Support\Facades\Auth;

class Chat extends Controller
{
    public function index()
    {
        return view("front.chat.index");
    }

    public function get_room_info($room)
    {
        $room_info = ChatRoom::where("room_id", "=", $room)->get();

        foreach($room_info as $d){
            if($d->user_id == Auth::user()->id){
                return view("front.chat.index", compact("room_info"));
            }else{
                return redirect('/');
            }
        }
        
    }
}
