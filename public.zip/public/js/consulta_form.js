let options_of_consulta = document.querySelectorAll(".servies_type");


options_of_consulta.forEach(option =>{
    option.addEventListener("click", ()=>{
        $.ajax({
            url: "/get_option_of_consulta/option/" + option.dataset.value,
            data: {
                option: option.dataset.value
            },
            method: "GET",
            // dataType: "json",
            success: function (response) {
                document.body.innerHTML += response
                valid_exit_button()
            },
            complete: function () {
                // chat_area.find(".loader").remove();
            }
        });
    })
})

function valid_exit_button(){
    let exit_button = document.querySelector(".exit_button");

    exit_button.addEventListener("click", ()=>{
        let form_options = document.querySelectorAll(".option_chooses_form");
        form_options.forEach(data =>{
            data.remove();
        })
    })
}