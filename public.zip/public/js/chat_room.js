let info_nputs = document.querySelectorAll(".form-group input");
let info_text = document.querySelectorAll(".form-group textarea");

//to make blur on focus to any information input
info_nputs.forEach(input =>{input.addEventListener("focus", ()=>{input.blur() }) })
info_text.forEach(input =>{input.addEventListener("focus", ()=>{input.blur() }) })

